# BLE 数据传输协议

## 版本信息

- 协议版本：v3 full EMG packet
- 更新日期：2026-07-06
- 适用固件：ESP32-C3 EMG v2.2

## BLE 配置

| 参数 | 值 |
|------|-----|
| 设备名称 | `LS_ARM_BICEPS` / `LS_ARM_TRICEPS` |
| Service UUID | `4fafc201-1fb5-459e-8fcc-c5c9c3319141` |
| Characteristic UUID | `beb5483e-36e1-4688-b7f5-ea07361b26a1` |
| 特征属性 | Notify |
| 发送频率 | 约 12.5 Hz |

## v3 数据格式

ESP32-C3 通过 BLE Notify 发送 16 字节二进制包，小端格式。

```text
偏移  长度  含义
0     2     魔数 ASCII: "LJ"
2     1     协议版本: 3
3     1     flags, bit0=1 表示校准中
4     2     seq, 包序号 uint16
6     2     raw, 真实 ADC 原始值 uint16, 0~4095
8     2     acRMS * 100, uint16
10    2     smooth * 100, uint16
12    2     baseline * 100, uint16
14    2     activation * 1000, uint16, 0~1000
```

解析示例：

```python
import struct

def parse(data: bytes):
    if len(data) != 16 or data[0:2] != b"LJ" or data[2] != 3:
        raise ValueError("not v3 packet")
    _, _, version, flags, seq, raw, ac100, sm100, base100, act1000 = struct.unpack(
        "<ccBBHHHHHH", data
    )
    return {
        "version": version,
        "flags": flags,
        "seq": seq,
        "raw": raw,
        "ac_rms": ac100 / 100.0,
        "smooth": sm100 / 100.0,
        "baseline": base100 / 100.0,
        "activation": act1000 / 1000.0,
    }
```

## 为什么从 v2 改为 v3

旧 v2/v2.1 BLE 包只发送 2 字节 `activation * 1000`。RDK 只能看到最终力度百分比，看不到真实 ADC 原始值、RMS、平滑值和基线，因此无法判断“0%”是传感器真的没有信号，还是 ESP32 算法把信号压成了 0。

v3 包直接发送真实肌电诊断字段，RDK 日志会显示：

```text
[BLE-DATA] ... len=16 v=3 flags=0x00 seq=12 raw=1096 ac=8.23 sm=8.14 base=6.50 act1000=273 act=0.273
```

其中 `raw` 是 ESP32 实际 ADC 采样值，不再是 RDK 用 `activation * 4095` 反推的估计值。

## 兼容说明

RDK 端仍兼容旧 2 字节协议：

```python
act1000 = data[0] | (data[1] << 8)
activation = act1000 / 1000.0
```

但旧协议没有真实 raw 值，RDK 只能标记为估计值。后续联调建议全部使用 v3 协议。
