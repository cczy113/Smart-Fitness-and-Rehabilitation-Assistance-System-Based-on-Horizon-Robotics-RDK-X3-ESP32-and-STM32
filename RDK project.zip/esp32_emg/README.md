# ESP32-C3 EMG 采集固件 — 灵境守护

## 版本信息
- **固件版本**: v2.0 (单通道 BLE + 串口 CSV)
- **更新日期**: 2026-07-06
- **硬件平台**: ESP32-C3-DevKitM-1
- **框架**: Arduino (PlatformIO)

## 更新日志

### v2.0 (2026-07-06)
- 改为单通道 BLE 传输 + 串口 CSV 输出
- 串口输出 5 列浮点数据：`raw, acRMS, smooth, baseline, act`
- 自适应满量程：`act` 根据实际最大收缩自动调整
- 波形查看器支持自动缩放 Y 轴
- 新增 BLE 协议文档

### v1.0 (旧版)
- 双通道 UART 帧协议（17 字节二进制帧）
- 已废弃

## 目录结构

```
esp32_emg_firmware/
├── platformio.ini          # PlatformIO 项目配置 (ESP32-C3)
├── src/
│   └── main.cpp            # 固件: 单通道 EMG 采集 + BLE 通知 + 串口 CSV
├── rdk/
│   └── emg_parser.py       # RDK X3 端: 双 UART 帧解析 → WebSocket JSON
├── tools/
│   ├── emg_viewer.py       # PC 调试工具: 串口 5 列实时波形显示 (自动缩放)
│   ├── emg_ble_viewer.py   # PC 调试工具: BLE 无线波形查看
│   ├── emg_calibrate.py    # PC 标定工具: 静息值 + 最大收缩值标定
│   └── test_serial.py      # 简单串口测试
└── docs/
    └── ble_protocol.md     # BLE 数据传输协议文档
```

## 硬件接线

| ESP32-C3 Pin | 连接对象 |
|--------------|---------|
| GPIO0 (ADC1_CH0) | EMG 传感器信号输出 |
| 3.3V / 5V | EMG 传感器 VCC |
| GND | EMG 传感器 GND |
| GPIO8 | 内置 LED (状态指示) |

## 使用步骤

### 1. 编译烧录

```bash
# 使用 PlatformIO CLI
pio run -t upload

# 或在 VS Code 中点击 PlatformIO 工具栏的 Upload 按钮
```

### 2. 上电校准

- 上电后 LED 慢闪（约 8 秒），**保持肌肉放松**
- 校准完成后 LED 停止闪烁，开始输出数据

### 3. PC 调试 (USB 串口)

```bash
# 安装依赖
pip install pyserial matplotlib

# 实时波形查看 (5 列: raw, acRMS, smooth, baseline, act)
python tools/emg_viewer.py -p COM8

# BLE 无线波形查看
pip install bleak
python tools/emg_ble_viewer.py
```

### 4. BLE 数据传输

固件通过 BLE 广播 `activation` 数据（2 字节二进制，小端格式）。

**协议详情**: [docs/ble_protocol.md](docs/ble_protocol.md)

**接收端示例**:
```python
from bleak import BleakClient

def on_notify(sender, data):
    act1000 = data[0] | (data[1] << 8)
    activation = act1000 / 1000.0
    print(f"Activation: {activation:.3f}")

# 连接设备
device = await BleakScanner.find_device_by_name("LS_ARM_BICEPS")
async with BleakClient(device) as client:
    await client.start_notify("beb5483e-36e1-4688-b7f5-ea07361b26a1", on_notify)
```

### 5. 传感器标定

```bash
python tools/emg_calibrate.py --port COM8
```

## 串口数据格式

CSV 格式，5 列，115200 波特率：

```
raw,acRMS,smooth,baseline,act
```

| 列 | 含义 | 范围 |
|----|------|------|
| raw | 原始 ADC 值 | 0 ~ 4095 |
| acRMS | 窗口均方根 (200 点) | 浮点数 |
| smooth | EMA 平滑值 (α=0.15) | 浮点数 |
| baseline | 自适应基线 | 浮点数 |
| act | 激活度 (自适应满量程) | 0.0 ~ 1.0 |

## 开发计划

- [x] 固件: 单通道 EMG ADC 采集 + 滑动窗口 RMS + EMA 平滑
- [x] 校准: 上电 8 秒自动基线校准
- [x] BLE 传输: 2 字节二进制 Notify (act*1000)
- [x] 串口输出: 5 列浮点 CSV
- [x] PC 工具: 实时波形查看 (自动缩放)
- [x] 自适应满量程: act 根据实际最大收缩自动调整
- [ ] 心跳检测 + 断连重连
- [ ] 全链路联调: ESP32 → RDK X3 → Unity

## Codex 修订说明 v2.1 (2026-07-06)

本次针对 RDK 接收到肌电数据长期为 0% 的问题，检查发现旧 `src/main.cpp` 中存在两处容易导致 `act` 长期为 0 的风险：

1. README 写的是上电约 8 秒校准，但旧代码使用 `calCnt < 80` 统计循环次数，实际校准期可能只有几十毫秒，容易把上电瞬间噪声当作基线。
2. `maxAbove` 只增不降，且死区和初始满量程较硬，轻微收缩容易被压成 0。

Codex 已将 `src/main.cpp` 修订为 v2.1：

- 校准改为真实时间 `CALIBRATION_MS = 8000`。
- 保持放松时 LED 慢闪，校准结束后开始 BLE Notify。
- BLE 协议不变：2 字节小端 `activation * 1000`。
- 串口 CSV 格式不变：`raw,acRMS,smooth,baseline,act`。
- 死区降低为 `DEADZONE = 0.8f`。
- `maxAbove` 支持慢速回落，避免一次大噪声或强收缩后长期满量程过大。
- 保留两个设备名方案：第一块 `LS_ARM_BICEPS`，第二块烧录前手动改为 `LS_ARM_TRICEPS`。

重新烧录后，务必在上电校准 8 秒内保持肌肉放松；校准结束后再做收缩测试。

## Codex 修订说明 v2.2 (2026-07-06)

本次针对“RDK 端仍显示 0%，且日志中的 raw 并不是真实肌电数据”的问题继续修订。

原因：
- v2.1 BLE Notify 只发送 2 字节 `activation * 1000`。
- RDK 日志里的 `raw` 只能用 `activation * 4095` 估算，不能代表 ESP32 ADC 的真实采样值。
- 当 `activation` 长期为 0 时，RDK 无法判断是传感器信号本身太弱，还是 ESP32 算法/标定把信号压成了 0。

Codex 已将 BLE 协议升级为 v3 16 字节真实 EMG 包：
- 魔数和版本：`LJ`, version=3。
- 包含真实 `raw` ADC 值。
- 包含 `acRMS`、`smooth`、`baseline`、`activation`。
- 包含 `seq` 包序号和 `flags`。

RDK 新日志会显示类似：

```text
[BLE-DATA] LS_ARM_BICEPS->biceps_l len=16 v=3 flags=0x00 seq=12 raw=1096 ac=8.23 sm=8.14 base=6.50 act1000=273 act=0.273
```

其中 `raw` 是 ESP32 真正发来的 ADC 原始采样值。
