﻿/*
 * LingJing - ESP32-C3 EMG BLE firmware v2.2
 * ------------------------------------------------------------
 * Single-channel EMG acquisition.
 * Serial CSV: raw,acRMS,smooth,baseline,act
 * BLE Notify: 16-byte binary packet with raw/acRMS/smooth/baseline/activation.
 *
 * Power-on calibration lasts CALIBRATION_MS. Keep the muscle relaxed while
 * the LED blinks. After calibration, LED indicates activation strength.
 */

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLE2902.h>

#define DEVICE_NAME "LS_ARM_BICEPS"  // Change the second board to LS_ARM_TRICEPS.
#define SERVICE_UUID "4fafc201-1fb5-459e-8fcc-c5c9c3319141"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a1"

const int emgPin = 0;  // ESP32-C3 ADC1_CH0 / GPIO0.
const int ledPin = 8;

const uint16_t WIN = 200;
const uint32_t SAMPLE_US = 480;
const uint32_t OUTPUT_MS = 80;       // About 12.5 Hz BLE Notify.
const uint32_t CALIBRATION_MS = 8000;

const float EMA_ALPHA = 0.15f;
const float BASELINE_ALPHA = 0.0005f;
const float DEADZONE = 0.8f;
const float MIN_SCALE = 6.0f;
const float SCALE_DECAY = 0.0008f;

uint16_t buf[WIN];
uint16_t bi = 0;
uint64_t ssq = 0;
uint64_t ssum = 0;
bool filled = false;

float acRMS = 0.0f;
float smooth = 0.0f;
float baseline = 0.0f;
float act = 0.0f;
float maxAbove = MIN_SCALE;
uint16_t latestRaw = 0;

uint32_t sampleCount = 0;
uint32_t calibrationStartMs = 0;
uint32_t lastOutMs = 0;
uint16_t packetSeq = 0;

BLECharacteristic *pChar = nullptr;
bool bleOk = false;

bool inCalibration(uint32_t now);

class CB : public BLEServerCallbacks {
    void onConnect(BLEServer *s) override { bleOk = true; }
    void onDisconnect(BLEServer *s) override {
        bleOk = false;
        s->getAdvertising()->start();
    }
};

void setupBle() {
    BLEDevice::init(DEVICE_NAME);
    BLEDevice::setPower(ESP_PWR_LVL_P9);
    BLEServer *server = BLEDevice::createServer();
    server->setCallbacks(new CB());
    BLEService *service = server->createService(SERVICE_UUID);
    pChar = service->createCharacteristic(CHARACTERISTIC_UUID, BLECharacteristic::PROPERTY_NOTIFY);
    pChar->addDescriptor(new BLE2902());
    service->start();
    server->getAdvertising()->start();
}

void updateEmg() {
    uint16_t old = buf[bi];
    uint16_t raw = analogRead(emgPin);
    latestRaw = raw;

    ssq -= (uint64_t)old * old;
    ssum -= old;
    buf[bi] = raw;
    ssq += (uint64_t)raw * raw;
    ssum += raw;

    bi++;
    if (bi >= WIN) {
        bi = 0;
        filled = true;
    }
    if (!filled) return;

    float mean = (float)ssum / (float)WIN;
    float variance = (float)ssq / (float)WIN - mean * mean;
    if (variance < 0.0f) variance = 0.0f;
    acRMS = sqrtf(variance);

    if (sampleCount == 0) smooth = acRMS;
    smooth += EMA_ALPHA * (acRMS - smooth);
    sampleCount++;
}

uint16_t scaledU16(float value, float scale) {
    float scaled = roundf(value * scale);
    if (scaled < 0.0f) return 0;
    if (scaled > 65535.0f) return 65535;
    return (uint16_t)scaled;
}

void putU16LE(uint8_t *d, uint8_t offset, uint16_t value) {
    d[offset] = (uint8_t)(value & 0xFF);
    d[offset + 1] = (uint8_t)(value >> 8);
}

void fillBlePacket(uint8_t *d, uint32_t now) {
    d[0] = 'L';
    d[1] = 'J';
    d[2] = 3;  // EMG BLE packet version v3.
    d[3] = inCalibration(now) ? 0x01 : 0x00;
    putU16LE(d, 4, packetSeq++);
    putU16LE(d, 6, latestRaw);
    putU16LE(d, 8, scaledU16(acRMS, 100.0f));
    putU16LE(d, 10, scaledU16(smooth, 100.0f));
    putU16LE(d, 12, scaledU16(baseline, 100.0f));
    putU16LE(d, 14, scaledU16(constrain(act, 0.0f, 1.0f), 1000.0f));
}

bool inCalibration(uint32_t now) {
    return now - calibrationStartMs < CALIBRATION_MS;
}

void updateActivation(uint32_t now) {
    if (inCalibration(now)) {
        // True time-based calibration. The old firmware counted 80 loop passes,
        // which finished in only a few tens of milliseconds.
        if (sampleCount <= 1) baseline = smooth;
        baseline += 0.01f * (smooth - baseline);
        act = 0.0f;
        return;
    }

    if (smooth < baseline + 3.0f) {
        baseline += BASELINE_ALPHA * (smooth - baseline);
    }

    float above = smooth - baseline;
    if (above < DEADZONE) above = 0.0f;

    if (above > maxAbove) {
        maxAbove = above;
    } else if (maxAbove > MIN_SCALE) {
        maxAbove += SCALE_DECAY * (above - maxAbove);
        if (maxAbove < MIN_SCALE) maxAbove = MIN_SCALE;
    }

    act = constrain(above / maxAbove, 0.0f, 1.0f);
}

void updateLed(uint32_t now) {
    if (inCalibration(now)) {
        digitalWrite(ledPin, (now % 500 < 250) ? LOW : HIGH);
        return;
    }
    digitalWrite(ledPin,
                 (act > 0.6f) ? LOW :
                 (act > 0.2f && now % 300 < 80) ? LOW :
                 (act > 0.03f && now % 1000 < 50) ? LOW : HIGH);
}

void outputData(uint32_t now) {
    if (now - lastOutMs < OUTPUT_MS) return;
    lastOutMs = now;

    Serial.print(latestRaw);
    Serial.print(',');
    Serial.print(acRMS, 2);
    Serial.print(',');
    Serial.print(smooth, 2);
    Serial.print(',');
    Serial.print(baseline, 2);
    Serial.print(',');
    Serial.println(act, 3);

    if (!inCalibration(now) && bleOk && pChar) {
        uint8_t d[16];
        fillBlePacket(d, now);
        pChar->setValue(d, sizeof(d));
        pChar->notify();
    }
}

void setup() {
    Serial.begin(115200);
    pinMode(ledPin, OUTPUT);
    digitalWrite(ledPin, HIGH);

    analogSetAttenuation(ADC_11db);
    analogReadResolution(12);

    setupBle();
    memset(buf, 0, sizeof(buf));
    calibrationStartMs = millis();
}

void loop() {
    static uint32_t lastSampleUs = 0;
    uint32_t nowUs = micros();
    if ((uint32_t)(nowUs - lastSampleUs) < SAMPLE_US) return;
    lastSampleUs = nowUs;

    updateEmg();
    if (!filled) return;

    uint32_t now = millis();
    updateActivation(now);
    updateLed(now);
    outputData(now);
}
