# Unity 人体模型通信协议及使用方法

> 文档版本：1.0  
> 核对日期：2026-07-13  
> 协议事实来源：`rdk_pose_fusion_bridge.py`  
> 适用范围：RDK X3 将人体二维姿态、双臂肌电、融合判断及系统状态发送给 Unity，Unity 据此驱动人体模型和界面。

## 1. 系统结构与通信方向

```text
摄像头 -> RDK 人体检测 -> rdk_pose_fusion_bridge.py -> WebSocket -> Unity -> 人体模型
ESP32 肌电板 -> BLE -------------------------------^
```

- RDK 是 WebSocket Server，Unity 是 WebSocket Client。
- 当前协议版本是**单向下行协议**：RDK 持续向 Unity 广播 JSON。
- Unity 发给 RDK 的消息当前会被读取后丢弃，不能控制 RDK、舵机或训练状态。若以后需要双向控制，必须先在 RDK 端定义命令白名单、应答和权限校验，不能直接假设已有接口。
- 默认 WebSocket 推送频率为 `20Hz`，可在启动桥接程序时用 `--ws-rate` 修改。

## 2. 连接参数

| 项目 | 当前值 |
|---|---|
| 传输协议 | WebSocket，明文 `ws://` |
| 服务端监听 | `0.0.0.0:8765` |
| Unity 连接格式 | `ws://<RDK_IP>:8765` |
| 当前现场示例 | `ws://192.168.137.230:8765` |
| 默认推送频率 | `20Hz` |
| 消息编码 | UTF-8 JSON 文本 |
| 消息类型 | `pose_fusion` |

Unity 设备和 RDK 必须位于可互通的局域网。现场 IP 可能随热点或 DHCP 改变，应以 RDK 当前实际 IP 为准，不要把示例地址永久写死到发布版本。

## 3. 完整数据帧

以下示例展示字段结构。数值仅用于说明；设备未连接、关键点不可用或系统指标尚未完成首次采样时，部分字段可能为 `null`、空数组或零值。

```json
{
  "timestamp": 1717500000123,
  "frame_id": 12345,
  "type": "pose_fusion",
  "skeleton": {
    "keypoints": [
      {"id": 0, "name": "nose", "x": 0.51000, "y": 0.22000, "conf": 0.9500},
      {"id": 1, "name": "left_eye", "x": 0.49000, "y": 0.18000, "conf": 0.9200},
      {"id": 2, "name": "right_eye", "x": 0.53000, "y": 0.18000, "conf": 0.9300},
      {"id": 3, "name": "left_ear", "x": 0.45000, "y": 0.20000, "conf": 0.8800},
      {"id": 4, "name": "right_ear", "x": 0.57000, "y": 0.20000, "conf": 0.8900},
      {"id": 5, "name": "left_shoulder", "x": 0.38000, "y": 0.40000, "conf": 0.9600},
      {"id": 6, "name": "right_shoulder", "x": 0.62000, "y": 0.40000, "conf": 0.9700},
      {"id": 7, "name": "left_elbow", "x": 0.32000, "y": 0.55000, "conf": 0.9400},
      {"id": 8, "name": "right_elbow", "x": 0.68000, "y": 0.55000, "conf": 0.9500},
      {"id": 9, "name": "left_wrist", "x": 0.28000, "y": 0.68000, "conf": 0.9100},
      {"id": 10, "name": "right_wrist", "x": 0.72000, "y": 0.68000, "conf": 0.9200},
      {"id": 11, "name": "left_hip", "x": 0.42000, "y": 0.62000, "conf": 0.9400},
      {"id": 12, "name": "right_hip", "x": 0.58000, "y": 0.62000, "conf": 0.9500},
      {"id": 13, "name": "left_knee", "x": 0.41000, "y": 0.78000, "conf": 0.9300},
      {"id": 14, "name": "right_knee", "x": 0.59000, "y": 0.78000, "conf": 0.9400},
      {"id": 15, "name": "left_ankle", "x": 0.40000, "y": 0.93000, "conf": 0.9000},
      {"id": 16, "name": "right_ankle", "x": 0.60000, "y": 0.93000, "conf": 0.9100}
    ],
    "num_points": 17,
    "angles": {
      "left_elbow_flexion_deg": 90.0,
      "right_elbow_flexion_deg": 92.0,
      "shoulder_span_deg": 1.2
    }
  },
  "sensors": {
    "channels": {
      "biceps_l": {
        "raw": 2048,
        "ac_rms": 31.25,
        "smooth": 28.50,
        "baseline": 8.20,
        "seq": 321,
        "flags": 0,
        "packet_version": "v3_full",
        "force_pct": 55.2,
        "activation": 0.552,
        "timestamp": 1717500000100,
        "device": "LS_ARM_BICEPS",
        "status": "ok"
      },
      "biceps_r": {
        "raw": 0,
        "ac_rms": null,
        "smooth": null,
        "baseline": null,
        "seq": 0,
        "flags": 0,
        "packet_version": "",
        "force_pct": null,
        "activation": null,
        "timestamp": 0,
        "device": "",
        "status": "disconnected"
      }
    },
    "sensor_status": "partial"
  },
  "system": {
    "cpu_pct": 30.0,
    "memory_pct": 20.0,
    "memory_used_mb": 800.0,
    "memory_total_mb": 3930.4,
    "timestamp": 1717500000123
  },
  "alignment": {
    "biceps_l": {
      "emg_timestamp": 1717500000100,
      "pose_timestamp": 1717500000123,
      "delta_ms": 23
    },
    "biceps_r": {
      "emg_timestamp": 0,
      "pose_timestamp": 1717500000123,
      "delta_ms": null
    }
  },
  "assessment": {
    "upper_arm": {
      "left_elbow_flexion_deg": 90.0,
      "right_elbow_flexion_deg": 92.0,
      "angle_diff_deg": 2.0,
      "force_diff_pct": 55.2,
      "status": "ok"
    }
  },
  "alert": {
    "type": "none",
    "message": ""
  }
}
```

## 4. 顶层字段说明

| 字段 | JSON 类型 | 说明 |
|---|---|---|
| `timestamp` | integer | 当前姿态帧的毫秒时间戳；无有效姿态时间时使用 RDK 当前时间 |
| `frame_id` | integer | RDK 每收到一次 ROS 姿态回调加 1；不是 WebSocket 消息序号 |
| `type` | string | 固定为 `pose_fusion` |
| `skeleton` | object | 关键点、关键点数量和已计算关节角 |
| `sensors` | object | 左右肱二头肌通道和总体传感器状态 |
| `system` | object | RDK CPU、内存状态，约每秒更新一次 |
| `alignment` | object | 姿态与各肌电样本的接收时间差 |
| `assessment` | object | 当前上肢融合判断结果 |
| `alert` | object | 当前告警类型和英文说明 |

注意：WebSocket 可能以 20Hz 重复发送相同的 `frame_id`，但同一消息中的肌电或系统指标仍可能变化。因此 Unity 应用层应分别处理：模型姿态只接收更新的姿态帧，传感器和系统状态仍按每条有效消息刷新。

## 5. 人体关键点协议

### 5.1 单个关键点

```json
{"id": 7, "name": "left_elbow", "x": 0.32, "y": 0.55, "conf": 0.94}
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | integer | COCO 关键点编号 |
| `name` | string | 关键点英文名称 |
| `x` | number | 图像横向归一化坐标，通常为 `0~1` |
| `y` | number | 图像纵向归一化坐标，通常为 `0~1` |
| `conf` | number | 检测置信度，范围 `0~1` |

坐标系原点在摄像头图像左上角，`x` 向右，`y` 向下。当前 RDK 角度计算函数会拒绝置信度低于 `0.05` 的关键点；Unity 为减少抖动，建议使用更严格的显示阈值，例如 `0.2~0.4`，并通过现场测试确定。

### 5.2 COCO 17 点编号

| ID | 名称 | ID | 名称 |
|---:|---|---:|---|
| 0 | `nose` | 9 | `left_wrist` |
| 1 | `left_eye` | 10 | `right_wrist` |
| 2 | `right_eye` | 11 | `left_hip` |
| 3 | `left_ear` | 12 | `right_hip` |
| 4 | `right_ear` | 13 | `left_knee` |
| 5 | `left_shoulder` | 14 | `right_knee` |
| 6 | `right_shoulder` | 15 | `left_ankle` |
| 7 | `left_elbow` | 16 | `right_ankle` |
| 8 | `right_elbow` |  |  |

推荐骨骼连接关系：

```text
头部：0-1, 1-3, 0-2, 2-4
肩部：5-6
左臂：5-7, 7-9
右臂：6-8, 8-10
躯干：5-11, 6-12, 11-12
左腿：11-13, 13-15
右腿：12-14, 14-16
```

### 5.3 已计算角度

| 字段 | 单位 | 说明 |
|---|---|---|
| `left_elbow_flexion_deg` | degree | 左肩-左肘-左腕三点夹角 |
| `right_elbow_flexion_deg` | degree | 右肩-右肘-右腕三点夹角 |
| `shoulder_span_deg` | degree | 左肩到右肩连线相对图像 x 轴的有符号角度 |

角度可能为 `null`。Unity 不应把 `null` 当作 `0°`，否则人体模型会在检测丢失时突然折叠。

## 6. 肌电和系统状态

### 6.1 当前肌电通道

| 通道 | 含义 | 当前设备名映射 |
|---|---|---|
| `biceps_l` | 左臂肱二头肌 | `LS_ARM_BICEPS` |
| `biceps_r` | 右臂肱二头肌 | `LS_ARM_TRICEPS`，当前代码临时按右侧肱二头肌使用 |

桥接程序的数据结构始终包含两个通道，但当前默认启动配置只连接 `LS_ARM_BICEPS:biceps_l`，所以 `biceps_r` 默认很可能是 `disconnected`。只有 RDK 启动参数明确加入第二块板时，双侧肌力判断才有完整输入。

### 6.2 单通道字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `raw` | integer | ADC 原始值；旧版 2 字节包中可能只是由激活度反推的估算值 |
| `ac_rms` | number/null | 交流分量 RMS，仅完整 v3 包可靠提供 |
| `smooth` | number/null | 平滑值 |
| `baseline` | number/null | 基线值 |
| `seq` | integer | ESP32 包序号；旧协议可能一直为 0 |
| `flags` | integer | ESP32 状态标志 |
| `packet_version` | string | 例如 `v3_full`、`legacy2_estimated`、`ascii_estimated` |
| `force_pct` | number/null | 肌肉用力度百分比，在线时约为 `0~100` |
| `activation` | number/null | 归一化激活度，在线时为 `0~1` |
| `timestamp` | integer | RDK 收到最新肌电通知的毫秒时间 |
| `device` | string | BLE 设备广播名 |
| `status` | string | `ok` 或 `disconnected` |

设备断开或超过 3 秒没有新样本时，`status` 变为 `disconnected`，同时 `force_pct` 和 `activation` 变为 `null`。Unity 必须显示“未连接/无数据”，不能沿用旧值，也不能把它绘制成真实的 0% 肌力。

`sensors.sensor_status` 的当前规则为：两通道都在线时是 `ok`，否则是 `partial`。当前协议没有单独的 `disconnected` 总状态。

当前 RDK 即使只有一个通道在线，也会把另一侧按 `0` 参与 `force_diff_pct` 的数值计算，但不会触发 `bilateral_uneven`。因此 Unity 只有在两个通道的 `status` 都是 `ok` 时，才应把 `force_diff_pct` 显示为有效的双侧肌力差；否则应显示“数据不完整”。

### 6.3 系统资源

| 字段 | 说明 |
|---|---|
| `cpu_pct` | RDK 总 CPU 使用率百分比 |
| `memory_pct` | RDK 内存使用率百分比 |
| `memory_used_mb` | 已用内存，MB |
| `memory_total_mb` | 总内存，MB |
| `timestamp` | 本次系统指标采样时间 |

系统资源约每 1 秒采样一次，WebSocket 中间帧会重复最近一次缓存值，这是正常行为。

## 7. 时间对齐、融合判断和告警

### 7.1 时间对齐

每个肌电通道都包含：

```text
delta_ms = pose_timestamp - emg_timestamp
```

这只是 RDK 接收时间的差值，不是摄像头与 ESP32 的硬件同步结果。`delta_ms` 较大或为负时，应谨慎使用该肌电样本与当前姿态做精确时序判断；肌电未收到过数据时为 `null`。

### 7.2 上肢评估

`assessment.upper_arm` 字段：

| 字段 | 说明 |
|---|---|
| `left_elbow_flexion_deg` | 左肘角 |
| `right_elbow_flexion_deg` | 右肘角 |
| `angle_diff_deg` | 左右肘角绝对差；无完整角度时为 `null` |
| `force_diff_pct` | 左右肌力百分比绝对差 |
| `status` | `ok` 或 `warn` |

### 7.3 告警类型

| `alert.type` | 当前触发条件 | 优先级 |
|---|---|---:|
| `none` | 未触发异常 | 0 |
| `arm_angle_uneven` | 左右肘角均有效且角度差大于 `35°` | 1 |
| `bilateral_uneven` | 两个肌电通道均在线且肌力差大于 `30%` | 2 |

肌力不均告警优先于角度不均告警。阈值目前写在 RDK 代码中，不是 Unity 可配置参数。`alert.message` 当前是英文，Unity 若需中文语音，建议按 `alert.type` 映射本地中文文案，不要依赖英文字符串精确匹配。

## 8. Unity 接入方法

### 8.1 安装依赖

推荐使用：

1. `NativeWebSocket`：负责 WebSocket 连接。
2. Unity 官方 Newtonsoft Json 包：负责解析带 `null` 和嵌套对象的 JSON。

在 Unity Package Manager 中：

- 通过 Git URL 添加 `https://github.com/endel/NativeWebSocket.git#upm`
- 通过包名添加 `com.unity.nuget.newtonsoft-json`

不推荐直接使用 `JsonUtility`，因为当前协议含可空数值和具名通道对象，`JsonUtility` 很容易把 `null` 静默变成默认零值，导致“断连被误判为 0% 肌力”。

### 8.2 数据类与 WebSocket 客户端

新建 `RdkPoseClient.cs`：

```csharp
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using NativeWebSocket;
using Newtonsoft.Json;
using UnityEngine;

[Serializable]
public class KeypointDto
{
    public int id;
    public string name;
    public float x;
    public float y;
    public float conf;
}

[Serializable]
public class AnglesDto
{
    public float? left_elbow_flexion_deg;
    public float? right_elbow_flexion_deg;
    public float? shoulder_span_deg;
}

[Serializable]
public class SkeletonDto
{
    public List<KeypointDto> keypoints;
    public int num_points;
    public AnglesDto angles;
}

[Serializable]
public class EmgChannelDto
{
    public int raw;
    public float? ac_rms;
    public float? smooth;
    public float? baseline;
    public int seq;
    public int flags;
    public string packet_version;
    public float? force_pct;
    public float? activation;
    public long timestamp;
    public string device;
    public string status;
}

[Serializable]
public class SensorChannelsDto
{
    public EmgChannelDto biceps_l;
    public EmgChannelDto biceps_r;
}

[Serializable]
public class SensorsDto
{
    public SensorChannelsDto channels;
    public string sensor_status;
}

[Serializable]
public class SystemDto
{
    public float? cpu_pct;
    public float? memory_pct;
    public float? memory_used_mb;
    public float? memory_total_mb;
    public long timestamp;
}

[Serializable]
public class AlignmentItemDto
{
    public long emg_timestamp;
    public long pose_timestamp;
    public long? delta_ms;
}

[Serializable]
public class AlignmentDto
{
    public AlignmentItemDto biceps_l;
    public AlignmentItemDto biceps_r;
}

[Serializable]
public class UpperArmDto
{
    public float? left_elbow_flexion_deg;
    public float? right_elbow_flexion_deg;
    public float? angle_diff_deg;
    public float force_diff_pct;
    public string status;
}

[Serializable]
public class AssessmentDto
{
    public UpperArmDto upper_arm;
}

[Serializable]
public class AlertDto
{
    public string type;
    public string message;
}

[Serializable]
public class PoseFusionDto
{
    public long timestamp;
    public long frame_id;
    public string type;
    public SkeletonDto skeleton;
    public SensorsDto sensors;
    public SystemDto system;
    public AlignmentDto alignment;
    public AssessmentDto assessment;
    public AlertDto alert;
}

public class RdkPoseClient : MonoBehaviour
{
    [SerializeField] private string serverUrl = "ws://192.168.137.230:8765";
    [SerializeField, Min(0.1f)] private float reconnectDelay = 2f;
    [SerializeField, Min(1024)] private int maxMessageBytes = 1024 * 1024;

    private WebSocket socket;
    private PoseFusionDto latestFrame;
    private bool hasUnreadFrame;
    private bool reconnecting;
    private long lastPoseFrameId = -1;

    public event Action<PoseFusionDto, bool> FrameReceived;

    private async void Start()
    {
        await ConnectAsync();
    }

    private async System.Threading.Tasks.Task ConnectAsync()
    {
        if (socket != null &&
            (socket.State == WebSocketState.Open || socket.State == WebSocketState.Connecting))
            return;

        socket = new WebSocket(serverUrl);
        socket.OnOpen += () =>
        {
            // RDK 进程重启后 frame_id 会从头计数，新连接必须重置基线。
            lastPoseFrameId = -1;
        };
        socket.OnMessage += bytes =>
        {
            try
            {
                if (bytes == null || bytes.Length == 0 || bytes.Length > maxMessageBytes)
                {
                    Debug.LogWarning($"RDK 消息长度异常：{bytes?.Length ?? 0} bytes");
                    return;
                }

                PoseFusionDto parsed = JsonConvert.DeserializeObject<PoseFusionDto>(
                    Encoding.UTF8.GetString(bytes));

                if (parsed == null || parsed.type != "pose_fusion")
                    return;

                // 只保留最新帧，避免网络短时拥塞后追赶旧动作。
                latestFrame = parsed;
                hasUnreadFrame = true;
            }
            catch (Exception e)
            {
                Debug.LogWarning($"RDK JSON 无效：{e.Message}");
            }
        };
        socket.OnError += error => Debug.LogWarning($"RDK WebSocket：{error}");
        socket.OnClose += _ =>
        {
            if (isActiveAndEnabled && !reconnecting)
                StartCoroutine(ReconnectLoop());
        };

        try
        {
            await socket.Connect();
        }
        catch (Exception e)
        {
            Debug.LogWarning($"连接 RDK 失败：{e.Message}");
            if (isActiveAndEnabled && !reconnecting)
                StartCoroutine(ReconnectLoop());
        }
    }

    private IEnumerator ReconnectLoop()
    {
        reconnecting = true;
        while (isActiveAndEnabled &&
               (socket == null || socket.State != WebSocketState.Open))
        {
            yield return new WaitForSecondsRealtime(reconnectDelay);
            var task = ConnectAsync();
            while (!task.IsCompleted)
                yield return null;
        }
        reconnecting = false;
    }

    private void Update()
    {
#if !UNITY_WEBGL || UNITY_EDITOR
        socket?.DispatchMessageQueue();
#endif
        if (!hasUnreadFrame || latestFrame == null)
            return;

        hasUnreadFrame = false;
        bool poseIsNew = latestFrame.frame_id > lastPoseFrameId;
        if (poseIsNew)
            lastPoseFrameId = latestFrame.frame_id;

        // 即使 poseIsNew 为 false，肌电和 system 仍可能已经更新。
        FrameReceived?.Invoke(latestFrame, poseIsNew);
    }

    private async void OnDestroy()
    {
        if (socket != null)
            await socket.Close();
    }
}
```

将脚本挂到常驻 GameObject，在 Inspector 中填写 RDK 地址。业务脚本订阅 `FrameReceived`：当 `poseIsNew == true` 时更新人体骨骼；每次回调均可更新肌电、系统状态和告警。

### 8.3 驱动人体模型的正确方式

RDK 当前提供的是单摄像头二维关键点，不含可靠深度。不要直接执行：

```csharp
bone.position = new Vector3(kp.x, kp.y, 0f);
```

更稳妥的实现流程：

1. 用父关节和子关节的二维向量计算肢段方向。
2. 将方向变化映射为 Unity Humanoid 骨骼的局部旋转。
3. 用 `Quaternion.Slerp` 平滑旋转，降低检测抖动。
4. 用左右髋中心估算根节点平面位置，根节点深度保持固定或由其他传感器补充。
5. 关键点置信度不足、坐标越界或缺失时，短时间保持上一姿态；超时后缓慢回到默认姿态。
6. 需要完整三维动作时，增加 IK、动作约束或深度估计，不能只靠二维坐标精确恢复前后方向。

简化的二维骨骼旋转示例：

```csharp
private static bool TryDirection(
    Dictionary<int, KeypointDto> points,
    int parentId,
    int childId,
    float minConfidence,
    out Vector2 direction)
{
    direction = default;
    if (!points.TryGetValue(parentId, out KeypointDto parent) ||
        !points.TryGetValue(childId, out KeypointDto child) ||
        parent.conf < minConfidence || child.conf < minConfidence)
        return false;

    direction = new Vector2(child.x - parent.x, -(child.y - parent.y));
    return direction.sqrMagnitude > 0.000001f;
}

private static void ApplyPlanarRotation(
    Transform bone,
    Vector2 direction,
    float smoothSpeed)
{
    float z = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
    Quaternion target = Quaternion.Euler(0f, 0f, z);
    bone.localRotation = Quaternion.Slerp(
        bone.localRotation,
        target,
        1f - Mathf.Exp(-smoothSpeed * Time.deltaTime));
}
```

实际 Humanoid 模型的骨骼初始轴向各不相同，需要保存 T-Pose 初始旋转，并为每根骨骼配置轴向偏移；不能假设所有模型都以 Unity x 轴作为骨骼前向。

### 8.4 镜像和左右侧验证

- 如果摄像头预览做了水平镜像，而检测坐标仍是原图坐标，Unity 可能需要使用 `x = 1 - x`。
- 不要一开始就交换 `left_*` 和 `right_*`。先让真人单独举左手，观察 Unity、RDK 检测画面和数值是否一致，再决定只镜像坐标还是交换左右标签。
- 镜像选项应作为 Inspector 配置或运行时设置，不应散落在多个骨骼脚本中。

## 9. 联调步骤

1. 确认 RDK 桥接程序正在监听 8765 端口。
2. 确认 Unity 设备能访问 RDK IP；编辑器和 RDK 不在同一网段时不会连接成功。
3. 在 Unity Console 观察 WebSocket 是否连接、是否持续收到 `pose_fusion`。
4. 先只显示 `frame_id`、17 个关键点和左右肘角，不立即驱动三维模型。
5. 真人单独移动左臂、右臂，确认左右映射和镜像关系。
6. 接入模型旋转并逐骨骼校准 T-Pose 轴向偏移。
7. 单独断开 ESP32，确认 Unity 显示“未连接”，且不会保留旧肌力或伪造肌力数据。
8. 恢复 ESP32，确认 `status`、`timestamp`、`packet_version` 与数值变化合理。
9. 制造左右角度差和左右发力差，核对 `alert.type` 及 Unity 中文提示。
10. 断开网络至少 10 秒后恢复，验证自动重连、无消息积压、模型能恢复更新。

可在电脑上用任意 WebSocket 客户端先查看原始 JSON，确认数据后再排查 Unity 模型映射，避免把网络问题和骨骼问题混在一起。

## 10. 异常处理要求

| 异常 | Unity 应对策略 |
|---|---|
| WebSocket 断开 | 显示离线状态，停止使用旧数据，延时重连 |
| JSON 缺字段/类型错误 | 捕获解析异常并丢弃该帧，不能让主线程崩溃 |
| `keypoints` 为空或少于 17 | 不更新受影响骨骼，超时后平滑回默认姿态 |
| 关键点置信度过低 | 保持上一可信姿态或降低该骨骼权重 |
| `force_pct == null` | 显示未连接/无数据，禁止按 0% 处理 |
| 相同 `frame_id` | 姿态不重复应用，但仍处理肌电和系统字段 |
| 更小的 `frame_id` | 可能是乱序或 RDK 重启；结合连接重建决定重置序号基线 |
| 短时消息暴增 | 只保留最新完整帧，不排队回放历史动作 |
| 坐标越界/NaN | 丢弃对应关键点并记录限频日志 |
| 多人进入画面 | 当前 RDK 只选择第一个具有至少 17 点的目标，人物可能切换 |

## 11. 对抗式审查结论

- **网络攻击面**：当前是局域网明文 WebSocket，无认证、无加密。不要把 8765 端口暴露到公网；比赛局域网也应使用可信热点或防火墙限制访问。
- **恶意/异常数据**：Unity 必须限制消息大小、捕获 JSON 异常、校验类型和数值范围，避免超大消息、NaN 或错误坐标拖垮主线程。
- **并发边界**：网络回调只替换“最新帧”，所有 GameObject/Animator 操作放在 Unity 主线程。
- **失败恢复**：重连后允许 `frame_id` 从较小值重新开始，因为 RDK 进程重启会清零计数；建议在一次新连接建立时重置本地姿态帧基线。
- **数据真实性**：肌电断连时必须以 `status` 和 `null` 为准，禁止用缓存值伪装在线数据。
- **多人边界**：当前协议没有 `person_id`、目标跟踪 ID 或多人数组，无法保证遮挡或交叉后仍控制同一个人。
- **三维局限**：单目二维姿态无法可靠区分身体向前/向后运动，三维人体模型只能做受约束的近似驱动。

## 12. 版本演进建议（尚未实现）

后续修改 RDK 代码时，建议在协议中增加：

- `protocol_version`：明确兼容版本。
- `person_id`：稳定绑定被控制的人。
- `pose_status` 和 `pose_age_ms`：明确姿态是否过期。
- `session_id`：识别 RDK 重启并安全重置 `frame_id`。
- Unity→RDK 命令协议：采用 `request_id + command + parameters`，配套 `ack/error`，并只允许白名单命令。
- `wss://` 或应用层鉴权：用于非可信网络。

这些字段当前均不存在，Unity 第一版实现不得依赖它们。
