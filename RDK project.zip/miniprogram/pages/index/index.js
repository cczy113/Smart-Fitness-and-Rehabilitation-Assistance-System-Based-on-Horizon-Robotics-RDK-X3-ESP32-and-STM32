const rdkSocket = require('../../utils/rdkSocket')
const { getButtonLayout } = require('../../utils/layout')

Page({
  data: {
    statusText: "等待连接...",
    isConnected: false,
    isConnecting: false,
    rdkUrl: rdkSocket.getRdkUrl()
  },

  onLoad() {
    const layout = getButtonLayout()
    this.setData({
      rdkUrl: rdkSocket.getRdkUrl(),
      isConnected: rdkSocket.isConnected(),
      statusText: rdkSocket.isConnected() ? "已连接 RDK，点击进入监控" : "输入 RDK 地址后连接",
      buttonStyle: layout.buttonStyle,
      smallButtonStyle: layout.smallButtonStyle,
      cardButtonStyle: layout.cardButtonStyle,
      bottomPadding: layout.bottomPadding
    });
  },

  onResize() {
    const layout = getButtonLayout()
    this.setData({
      buttonStyle: layout.buttonStyle,
      smallButtonStyle: layout.smallButtonStyle,
      cardButtonStyle: layout.cardButtonStyle,
      bottomPadding: layout.bottomPadding
    })
  },

  onUrlInput(e) {
    const rdkUrl = e.detail.value
    this.setData({ rdkUrl })
    rdkSocket.setRdkUrl(rdkUrl)
  },

  connectDevice() {
    if (this.data.isConnected) {
      wx.redirectTo({ url: '/pages/monitor/monitor' });
      return;
    }

    this.setData({
      isConnecting: true,
      statusText: "正在连接 RDK..."
    });

    rdkSocket.connect({ url: this.data.rdkUrl }).then(() => {
      this.setData({
        isConnected: true,
        isConnecting: false,
        statusText: "连接成功，正在跳转..."
      });
      setTimeout(() => {
        wx.redirectTo({ url: '/pages/monitor/monitor' });
      }, 500);
    }).catch((err) => {
      this.setData({
        isConnected: false,
        isConnecting: false,
        statusText: "连接失败，请检查 RDK 是否启动"
      });
      wx.showModal({
        title: '连接失败',
        content: `${err && err.errMsg ? err.errMsg : err}`,
        showCancel: false
      });
    });
  }
})
