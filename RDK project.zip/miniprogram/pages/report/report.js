// pages/report/report.js 优化版：加打字机效果触发逻辑
const { getButtonLayout } = require('../../utils/layout')
Page({
  data: {
    reportData: {
      muscle: [0, 0, 0, 0],
      isAbnormal: false
    },
    aiReport: {},
    isLoading: false
  },

  onLoad(options) {
    const layout = getButtonLayout()
    this.setData({
      buttonStyle: layout.buttonStyle,
      smallButtonStyle: layout.smallButtonStyle,
      cardButtonStyle: layout.cardButtonStyle,
      bottomPadding: layout.bottomPadding
    })
    if (options.data) {
      const reportData = JSON.parse(decodeURIComponent(options.data));
      this.setData({ reportData });
      this.generateAIReport();
    }
  },

  onResize() {
    const layout = getButtonLayout()
    this.setData({
      buttonStyle: layout.buttonStyle,
      smallButtonStyle: layout.smallButtonStyle,
      cardButtonStyle: layout.cardButtonStyle,
      bottomPadding: layout.bottomPadding
    })
  },

  // 核心：AI生成报告（模拟版，加打字机效果触发）
  generateAIReport() {
    const that = this;
    const data = this.data.reportData;

    // 开启加载状态
    this.setData({
      isLoading: true,
      aiReport: {}
    });

    // 模拟AI分析延迟（1.5秒）
    setTimeout(() => {
      // 计算肌肉发力均衡度
      const muscleAvg = (data.muscle[0] + data.muscle[1] + data.muscle[2] + data.muscle[3]) / 4;
      const minMuscle = Math.min(...data.muscle);
      const maxMuscle = Math.max(...data.muscle);
      const balanceRate = maxMuscle === 0 ? 1 : minMuscle / maxMuscle;
      const balanceLevel = balanceRate > 0.8 ? "优秀" : balanceRate > 0.6 ? "一般" : "较差";

      // 生成模拟AI报告
      const aiReport = {
        overall: `本次检测采集到左右上臂肌电和肘关节角度数据，平均肌力值为${muscleAvg.toFixed(1)}，左右发力均衡度为${balanceLevel}，${data.isAbnormal ? "检测到动作或发力异常，存在运动损伤风险" : "动作与发力状态稳定，未发现明显异常"}。`,
        muscle: `本次检测中，左上臂肌力${data.muscle[0]}，右上臂肌力${data.muscle[2]}，左肘角${data.leftAngle || "--"}°，右肘角${data.rightAngle || "--"}°。${balanceRate > 0.8 ? "左右侧肌肉发力较均衡，动作控制状态较好，符合康复训练/健身动作监测要求。" : "左右侧肌肉发力差异较大，存在单侧过度发力或动作代偿的情况，建议降低负荷并重新调整动作。"}`,
        risk: data.isAbnormal ? 
          "本次检测中检测到异常代偿动作，提示您当前动作模式存在问题，深层肌肉发力不足，依赖表层肌肉代偿完成动作，若不及时纠正，极易造成二次损伤，建议立即停止当前训练，调整动作模式。" : 
          "本次检测未发现异常代偿动作，动作轨迹与肌肉发力匹配度高，无运动损伤风险，可继续保持当前的训练/康复节奏。",
        advice: balanceRate > 0.8 ? 
          "1. 继续保持当前标准的动作模式，维持肌肉均衡发力；2. 可逐步提升训练强度，每次训练后做好肌肉拉伸放松；3. 建议每周进行3-4次训练，每次时长控制在30-45分钟。" : 
          "1. 立即降低训练负荷，优先纠正动作模式，重点激活薄弱侧的深层肌肉；2. 增加单侧肌肉的激活训练，每次训练前做好10分钟的核心热身；3. 建议每次训练后对薄弱侧进行筋膜放松，每周进行2次平衡性训练；4. 若持续存在发力不均的情况，建议咨询专业康复师进行针对性调整。"
      };

      // 更新报告内容，触发打字机效果
      that.setData({
        aiReport: aiReport,
        isLoading: false
      });
    }, 1500);
  },

  // 返回首页
  goBack() {
    wx.redirectTo({
      url: '/pages/index/index'
    });
  }
})
