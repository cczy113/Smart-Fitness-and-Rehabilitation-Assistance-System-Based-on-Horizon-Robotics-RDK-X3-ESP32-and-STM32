const rdkSocket = require('../../utils/rdkSocket')
const { getButtonLayout } = require('../../utils/layout')

const ACTIONS = {
  double_curl: {
    title: '双臂弯举',
    instruction: '双肘同步弯曲至约 35°-110°，左右肘角差不超过 25°，两侧肌力均需达到 5%。',
    target: '双肘 35°-110°；双侧肌力均不少于 5%',
    requiredChannels: ['biceps_l', 'biceps_r'],
    checkAngle(left, right) { return left >= 35 && left <= 110 && right >= 35 && right <= 110 && Math.abs(left - right) <= 25 },
    checkForce(left, right) { return left >= 5 && right >= 5 && Math.abs(left - right) <= 45 }
  },
  left_curl: {
    title: '左臂弯举',
    instruction: '左肘弯曲至约 35°-110°，右臂保持接近伸直，左臂肌力需达到 5%。',
    target: '左肘 35°-110°；左臂肌力不少于 5%',
    requiredChannels: ['biceps_l'],
    checkAngle(left, right) { return left >= 35 && left <= 110 && right >= 145 },
    checkForce(left) { return left >= 5 }
  },
  right_curl: {
    title: '右臂弯举',
    instruction: '右肘弯曲至约 35°-110°，左臂保持接近伸直，右臂肌力需达到 5%。',
    target: '右肘 35°-110°；右臂肌力不少于 5%',
    requiredChannels: ['biceps_r'],
    checkAngle(left, right) { return right >= 35 && right <= 110 && left >= 145 },
    checkForce(left, right) { return right >= 5 }
  },
  double_hold: {
    title: '双臂等长保持',
    instruction: '双肘保持在约 70°-110°，稳定发力且避免左右明显不对称；双侧肌力均需达到 5%。',
    target: '双肘 70°-110°；双侧肌力均不少于 5%',
    requiredChannels: ['biceps_l', 'biceps_r'],
    checkAngle(left, right) { return left >= 70 && left <= 110 && right >= 70 && right <= 110 && Math.abs(left - right) <= 20 },
    checkForce(left, right) { return left >= 5 && right >= 5 && Math.abs(left - right) <= 35 }
  }
}

Page({
  data: {
    action: { title: '', instruction: '', target: '' },
    group: 1,
    completedGroups: 0,
    isRunning: false,
    waitingRelease: false,
    feedback: '点击开始训练后，等待 RDK 识别你的姿态。',
    feedbackType: 'idle',
    leftAngle: '--',
    rightAngle: '--',
    leftForce: '--',
    rightForce: '--',
    leftEmgStatus: '未接入',
    rightEmgStatus: '未接入',
    buttonStyle: '',
    smallButtonStyle: '',
    cardButtonStyle: '',
    bottomPadding: '16px',
    holdProgress: 0,
    rdkConnected: false,
    unsubscribe: null
  },

  onLoad(options) {
    const action = ACTIONS[options.action] || ACTIONS.double_curl
    this.actionDefinition = action
    this.holdStartedAt = 0
    this.lastAlertAt = 0
    const layout = getButtonLayout()
    this.setData({
      action: { title: action.title, instruction: action.instruction, target: action.target },
      rdkConnected: rdkSocket.isConnected(),
      buttonStyle: layout.buttonStyle,
      smallButtonStyle: layout.smallButtonStyle,
      cardButtonStyle: layout.cardButtonStyle,
      bottomPadding: layout.bottomPadding
    })
    const unsubscribe = rdkSocket.onData((payload) => this.applyPayload(payload))
    this.setData({ unsubscribe })
  },

  onResize() {
    const layout = getButtonLayout()
    this.setData({
      buttonStyle: layout.buttonStyle,
      smallButtonStyle: layout.smallButtonStyle,
      cardButtonStyle: layout.cardButtonStyle,
      bottomPadding: layout.bottomPadding
    })
  },

  number(value) {
    const result = Number(value)
    return Number.isFinite(result) ? result : null
  },

  display(value) {
    const number = this.number(value)
    return number === null ? '--' : number.toFixed(1)
  },

  displayForce(value, status) {
    if (status !== 'ok') return '--'
    const number = this.number(value)
    return number === null ? '--' : Math.max(0, Math.min(100, number)).toFixed(1)
  },

  emgStatus(channel) {
    return channel && channel.status === 'ok' ? '已接入' : '未接入'
  },

  requiredEmgMessage(channels) {
    const missing = this.actionDefinition.requiredChannels.filter((name) => (channels[name] || {}).status !== 'ok')
    if (!missing.length) return ''
    const labels = missing.map((name) => name === 'biceps_l' ? '左臂 ESP32' : '右臂 ESP32')
    return `请先连接${labels.join('和')}，当前训练需要真实肌力数据。`
  },

  applyPayload(payload) {
    if (!payload) return
    const upper = (payload.assessment && payload.assessment.upper_arm) || {}
    const channels = (payload.sensors && payload.sensors.channels) || {}
    const leftChannel = channels.biceps_l || {}
    const rightChannel = channels.biceps_r || {}
    const left = this.number(upper.left_elbow_flexion_deg)
    const right = this.number(upper.right_elbow_flexion_deg)
    const leftForce = leftChannel.status === 'ok' ? this.number(leftChannel.force_pct) : null
    const rightForce = rightChannel.status === 'ok' ? this.number(rightChannel.force_pct) : null
    this.setData({
      rdkConnected: true,
      leftAngle: this.display(left),
      rightAngle: this.display(right),
      leftForce: this.displayForce(leftForce, leftChannel.status),
      rightForce: this.displayForce(rightForce, rightChannel.status),
      leftEmgStatus: this.emgStatus(leftChannel),
      rightEmgStatus: this.emgStatus(rightChannel)
    })
    if (!this.data.isRunning || this.data.completedGroups >= 3) return
    if (left === null || right === null) {
      this.resetHold('请完整面向摄像头，等待 RDK 识别双肘。', 'waiting')
      return
    }

    const emgMessage = this.requiredEmgMessage(channels)
    if (emgMessage) {
      this.resetHold(emgMessage, 'waiting')
      return
    }
    const angleCorrect = this.actionDefinition.checkAngle(left, right)
    if (this.data.waitingRelease) {
      if (!angleCorrect) this.setData({ waitingRelease: false, feedback: '已复位，可以开始下一组。', feedbackType: 'waiting', holdProgress: 0 })
      return
    }
    if (!angleCorrect) {
      this.resetHold('肘角未达到当前训练要求，请按提示调整。', 'warning')
      this.warnOnce()
      return
    }
    if (!this.actionDefinition.checkForce(leftForce, rightForce)) {
      this.resetHold('姿态已达到要求，但对应肌力不足或双侧发力不均，请主动收缩目标肌肉。', 'warning')
      this.warnOnce()
      return
    }

    const now = Date.now()
    if (!this.holdStartedAt) this.holdStartedAt = now
    const elapsed = now - this.holdStartedAt
    const progress = Math.min(100, Math.round(elapsed * 100 / 1500))
    if (elapsed < 1500) {
      this.setData({ feedback: '角度和肌力均合格，保持 1.5 秒完成本组。', feedbackType: 'correct', holdProgress: progress })
      return
    }
    const completedGroups = this.data.completedGroups + 1
    this.holdStartedAt = 0
    this.setData({
      completedGroups,
      group: Math.min(3, completedGroups + 1),
      waitingRelease: completedGroups < 3,
      isRunning: completedGroups < 3,
      holdProgress: 100,
      feedback: completedGroups === 3 ? '3 组训练完成，做得很好！' : `第 ${completedGroups} 组完成，请放下手臂复位后开始下一组。`,
      feedbackType: 'complete'
    })
    wx.vibrateShort({ type: 'medium' })
  },

  resetHold(feedback, feedbackType) {
    this.holdStartedAt = 0
    this.setData({ feedback, feedbackType, holdProgress: 0 })
  },

  warnOnce() {
    const now = Date.now()
    if (now - this.lastAlertAt < 1500) return
    this.lastAlertAt = now
    wx.vibrateShort({ type: 'heavy' })
  },

  startTraining() {
    if (!this.data.rdkConnected) {
      this.setData({ feedback: 'RDK 未连接，请返回设备连接页。', feedbackType: 'warning' })
      return
    }
    const latest = rdkSocket.getLatestPayload() || {}
    const channels = (latest.sensors && latest.sensors.channels) || {}
    const emgMessage = this.requiredEmgMessage(channels)
    if (emgMessage) {
      this.setData({ feedback: emgMessage, feedbackType: 'warning' })
      this.warnOnce()
      return
    }
    this.holdStartedAt = 0
    this.setData({ isRunning: true, waitingRelease: false, feedback: '训练已开始，请完成第 1 组动作。', feedbackType: 'waiting', holdProgress: 0 })
  },

  restartTraining() {
    this.holdStartedAt = 0
    this.setData({ group: 1, completedGroups: 0, isRunning: true, waitingRelease: false, feedback: '训练重新开始，请完成第 1 组动作。', feedbackType: 'waiting', holdProgress: 0 })
  },

  goBack() {
    wx.navigateBack({ delta: 1 })
  },

  onUnload() {
    if (this.data.unsubscribe) this.data.unsubscribe()
  }
})
