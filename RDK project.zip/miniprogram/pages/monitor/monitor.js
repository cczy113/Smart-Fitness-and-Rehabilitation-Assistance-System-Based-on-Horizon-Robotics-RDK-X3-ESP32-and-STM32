const rdkSocket = require('../../utils/rdkSocket')
const { getButtonLayout } = require('../../utils/layout')

Page({
  data: {
    muscleData: [0, 0, 0, 0],
    avgMuscle: 0,
    balanceRate: 100,
    isDetecting: true,
    waveBg: '',
    waveShift: false,
    statusText: '等待 RDK 数据...',
    leftAngle: '--',
    rightAngle: '--',
    rdkConnected: false,
    lastFrameId: 0,
    cpuPct: '--',
    memoryPct: '--',
    memoryText: '--',
    buttonStyle: '',
    smallButtonStyle: '',
    cardButtonStyle: '',
    bottomPadding: '16px',
    unsubscribe: null
  },

  onLoad() {
    // Keep a short, real force history so the trend chart does not flicker randomly.
    this.waveHistory = { left: [], right: [] }
    this.lastWaveUpdateMs = 0
    this.waveAnimationTimer = null
    this.setData({ waveBg: this.generateWaveByMuscle([0, 0, 0, 0], true) })
    const layout = getButtonLayout()
    this.setData({
      rdkConnected: rdkSocket.isConnected(),
      buttonStyle: layout.buttonStyle,
      smallButtonStyle: layout.smallButtonStyle,
      cardButtonStyle: layout.cardButtonStyle,
      bottomPadding: layout.bottomPadding
    })
    const unsubscribe = rdkSocket.onData((payload) => this.applyRdkPayload(payload))
    this.setData({ unsubscribe })

    if (!rdkSocket.isConnected()) {
      rdkSocket.connect().then(() => {
        this.setData({ rdkConnected: true, statusText: 'RDK 已连接' })
      }).catch(() => {
        this.setData({ rdkConnected: false, statusText: 'RDK 未连接，请返回重连' })
      })
    }
  },

  onResize() {
    const layout = getButtonLayout()
    this.setData({
      buttonStyle: layout.buttonStyle,
      smallButtonStyle: layout.smallButtonStyle,
      cardButtonStyle: layout.cardButtonStyle,
      bottomPadding: layout.bottomPadding
    })
  },

  num(value, fallback = 0) {
    const n = Number(value)
    return Number.isFinite(n) ? n : fallback
  },

  displayAngle(value) {
    const n = Number(value)
    return Number.isFinite(n) ? n.toFixed(1) : '--'
  },

  applyRdkPayload(payload) {
    if (!this.data.isDetecting || !payload) return

    const channels = (payload.sensors && payload.sensors.channels) || {}
    const left = channels.biceps_l || {}
    const right = channels.biceps_r || {}
    const upper = (payload.assessment && payload.assessment.upper_arm) || {}
    const system = payload.system || {}

    // A disconnected channel must not continue rendering its last cached force.
    const leftForce = left.status === 'ok' ? Math.max(0, Math.min(100, this.num(left.force_pct))) : 0
    const rightForce = right.status === 'ok' ? Math.max(0, Math.min(100, this.num(right.force_pct))) : 0
    const muscleData = [
      Math.round(leftForce),
      0,
      Math.round(rightForce),
      0
    ]
    const activeForces = [leftForce, rightForce].filter((v) => v > 0)
    const avg = activeForces.length
      ? activeForces.reduce((sum, v) => sum + v, 0) / activeForces.length
      : 0
    const max = Math.max(leftForce, rightForce)
    const min = Math.min(leftForce, rightForce)
    const balance = max === 0 ? 100 : Math.floor((min / max) * 100)
    const now = Date.now()
    // Data text can follow every frame; SVG rebuilding is capped for smooth device rendering.
    const shouldRefreshWave = now - this.lastWaveUpdateMs >= 120
    const update = {
      muscleData,
      avgMuscle: avg.toFixed(1),
      balanceRate: balance,
      statusText: 'RDK 数据接收正常',
      leftAngle: this.displayAngle(upper.left_elbow_flexion_deg),
      rightAngle: this.displayAngle(upper.right_elbow_flexion_deg),
      rdkConnected: true,
      lastFrameId: payload.frame_id || 0,
      cpuPct: this.displayMetric(system.cpu_pct, '%'),
      memoryPct: this.displayMetric(system.memory_pct, '%'),
      memoryText: this.memoryText(system.memory_used_mb, system.memory_total_mb)
    }
    if (shouldRefreshWave) {
      update.waveBg = this.generateWaveByMuscle(muscleData)
      update.waveShift = false
      this.lastWaveUpdateMs = now
    }
    this.setData(update, () => {
      if (!shouldRefreshWave) return
      // Reset then advance one sample width, like a bedside monitor trace.
      if (this.waveAnimationTimer) clearTimeout(this.waveAnimationTimer)
      this.waveAnimationTimer = setTimeout(() => {
        if (this.data.isDetecting) this.setData({ waveShift: true })
      }, 16)
    })
  },

  displayMetric(value, suffix = '') {
    const n = Number(value)
    return Number.isFinite(n) ? `${n.toFixed(1)}${suffix}` : '--'
  },

  memoryText(used, total) {
    const usedNumber = Number(used)
    const totalNumber = Number(total)
    if (!Number.isFinite(usedNumber) || !Number.isFinite(totalNumber)) return '等待 RDK 指标'
    return `${usedNumber.toFixed(0)} / ${totalNumber.toFixed(0)} MB`
  },

  generateWaveByMuscle(muscleData, reset = false) {
    const historySize = 48
    const left = Math.max(0, Math.min(100, this.num(muscleData[0])))
    const right = Math.max(0, Math.min(100, this.num(muscleData[2])))

    if (reset || !this.waveHistory) {
      this.waveHistory = {
        left: Array(historySize).fill(left),
        right: Array(historySize).fill(right)
      }
    } else {
      this.waveHistory.left.push(left)
      this.waveHistory.right.push(right)
      this.waveHistory.left = this.waveHistory.left.slice(-historySize)
      this.waveHistory.right = this.waveHistory.right.slice(-historySize)
    }

    const width = 960
    const height = 300
    const padding = 18
    const chartHeight = height - padding * 2
    const toPath = (points) => points.map((value, index) => {
      const x = (index / (historySize - 1)) * width
      const y = height - padding - (value / 100) * chartHeight
      return `${index === 0 ? 'M' : 'L'}${x.toFixed(1)} ${y.toFixed(1)}`
    }).join(' ')
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
      <defs>
        <linearGradient id="leftFill" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#35c5ff" stop-opacity=".25"/><stop offset="1" stop-color="#35c5ff" stop-opacity="0"/></linearGradient>
        <linearGradient id="rightFill" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#73f84d" stop-opacity=".22"/><stop offset="1" stop-color="#73f84d" stop-opacity="0"/></linearGradient>
      </defs>
      <path d="${toPath(this.waveHistory.left)} L${width} ${height} L0 ${height} Z" fill="url(#leftFill)"/>
      <path d="${toPath(this.waveHistory.right)} L${width} ${height} L0 ${height} Z" fill="url(#rightFill)"/>
      <path d="${toPath(this.waveHistory.left)}" stroke="#35c5ff" stroke-width="5" stroke-linejoin="round" stroke-linecap="round" fill="none"/>
      <path d="${toPath(this.waveHistory.right)}" stroke="#73f84d" stroke-width="5" stroke-linejoin="round" stroke-linecap="round" fill="none"/>
    </svg>`
    return `url('data:image/svg+xml;utf8,${encodeURIComponent(svg)}')`
  },

  stopDetect() {
    this.setData({
      isDetecting: false,
      statusText: '检测已停止，正在生成报告...'
    })
  },

  gotoReport() {
    this.stopDetect()
    const currentData = encodeURIComponent(JSON.stringify({
      muscle: this.data.muscleData,
      avgMuscle: this.data.avgMuscle,
      balanceRate: this.data.balanceRate,
      errorCount: 0,
      leftAngle: this.data.leftAngle,
      rightAngle: this.data.rightAngle,
      lastFrameId: this.data.lastFrameId
    }))
    setTimeout(() => {
      wx.navigateTo({
        url: `/pages/report/report?data=${currentData}`
      })
    }, 500)
  },

  enterTraining(e) {
    const action = e.currentTarget.dataset.action
    wx.navigateTo({ url: `/pages/training/training?action=${action}` })
  },

  gotoIndex() {
    this.stopDetect()
    wx.redirectTo({
      url: '/pages/index/index'
    })
  },

  onUnload() {
    if (this.waveAnimationTimer) clearTimeout(this.waveAnimationTimer)
    if (this.data.unsubscribe) {
      this.data.unsubscribe()
    }
  }
})
