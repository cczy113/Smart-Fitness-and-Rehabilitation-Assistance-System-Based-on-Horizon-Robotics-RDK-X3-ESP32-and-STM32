function getButtonLayout() {
  // getSystemInfoSync is supported by older Mini Program runtimes as well.
  const info = wx.getSystemInfoSync()
  const width = Number(info.windowWidth) || 375
  const height = Number(info.windowHeight) || 667
  const safeBottom = info.safeArea && Number.isFinite(info.safeArea.bottom)
    ? Math.max(0, height - info.safeArea.bottom)
    : 0
  // Base touch targets on real pixels, then scale gently for compact screens.
  const compact = height < 700 || width < 360
  const buttonPx = compact ? 46 : 52
  const fontPx = compact ? 16 : 17
  return {
    buttonStyle: `min-height:${buttonPx}px;height:${buttonPx}px;line-height:${buttonPx}px;font-size:${fontPx}px;`,
    smallButtonStyle: `min-height:40px;height:40px;line-height:40px;font-size:${compact ? 13 : 14}px;`,
    cardButtonStyle: `min-height:${compact ? 78 : 88}px;height:${compact ? 78 : 88}px;`,
    bottomPadding: `${Math.max(16, safeBottom + 12)}px`
  }
}

module.exports = { getButtonLayout }
