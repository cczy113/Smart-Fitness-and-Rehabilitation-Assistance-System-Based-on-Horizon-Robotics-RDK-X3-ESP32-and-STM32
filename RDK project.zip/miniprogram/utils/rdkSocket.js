const DEFAULT_RDK_URL = 'ws://192.168.137.230:8765'

let socketTask = null
let connected = false
let latestPayload = null
const listeners = []

function getRdkUrl() {
  return wx.getStorageSync('rdkWsUrl') || DEFAULT_RDK_URL
}

function setRdkUrl(url) {
  wx.setStorageSync('rdkWsUrl', url || DEFAULT_RDK_URL)
}

function notify(payload) {
  latestPayload = payload
  listeners.slice().forEach((fn) => {
    try {
      fn(payload)
    } catch (err) {
      console.error('RDK listener error', err)
    }
  })
}

function connect(options = {}) {
  const url = options.url || getRdkUrl()
  if (socketTask && connected) {
    return Promise.resolve({ url, reused: true })
  }
  if (socketTask) {
    try {
      socketTask.close()
    } catch (err) {}
    socketTask = null
  }

  return new Promise((resolve, reject) => {
    let settled = false
    const timeoutId = setTimeout(() => {
      if (!settled) {
        settled = true
        reject(new Error('连接 RDK 超时'))
      }
    }, options.timeout || 6000)

    socketTask = wx.connectSocket({ url })

    socketTask.onOpen(() => {
      connected = true
      clearTimeout(timeoutId)
      if (!settled) {
        settled = true
        resolve({ url, reused: false })
      }
    })

    socketTask.onMessage((res) => {
      try {
        notify(JSON.parse(res.data))
      } catch (err) {
        console.error('RDK data parse error', err, res.data)
      }
    })

    socketTask.onClose(() => {
      connected = false
      socketTask = null
    })

    socketTask.onError((err) => {
      connected = false
      clearTimeout(timeoutId)
      if (!settled) {
        settled = true
        reject(err)
      }
    })
  })
}

function close() {
  connected = false
  if (socketTask) {
    try {
      socketTask.close()
    } catch (err) {}
  }
  socketTask = null
}

function onData(fn) {
  listeners.push(fn)
  if (latestPayload) fn(latestPayload)
  return () => {
    const index = listeners.indexOf(fn)
    if (index >= 0) listeners.splice(index, 1)
  }
}

function isConnected() {
  return connected
}

function getLatestPayload() {
  return latestPayload
}

module.exports = {
  DEFAULT_RDK_URL,
  connect,
  close,
  getLatestPayload,
  getRdkUrl,
  isConnected,
  onData,
  setRdkUrl
}
